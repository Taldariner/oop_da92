﻿using System;
using System.Collections.Generic;

namespace oooop
{
	public class GameObject
	{
		private string name;
		private int hpFull;
		private int hp;

		public GameObject()
		{

		}

		public GameObject(string name)
		{
			this.name = name;
			hpFull = 100;
			hp = 80;
		}

		

	

		
	}
}
