﻿using System;
namespace oooop
{
	public interface Usage
	{
		public void Use(Player p);
	}
}