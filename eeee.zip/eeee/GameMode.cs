﻿using System;
namespace oooop
{
	public enum GameMode
	{
		//Location(карта)
		Inventory
	}
}
    

